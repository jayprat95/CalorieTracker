//
//  main.m
//  DownPicker
//
//  Created by Ryan on 09/10/2015.
//  Copyright (c) 2015 Ryan. All rights reserved.
//

@import UIKit;
#import "DownPickerAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DownPickerAppDelegate class]));
    }
}
